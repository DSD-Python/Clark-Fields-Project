if ! command -v brew &>/dev/null; then
    echo "Homebrew not installed, installing now..."
    /bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/master/install.sh)"
else
    echo "Homebrew is already installed."
fi

if ! brew list firefox &>/dev/null; then
    echo "Firefox not installed, installing now..."
    brew install --cask firefox
else
    echo "Firefox is already installed."
fi

pip3 install --upgrade requests PyQt5 selenium cryptography pyNaCl

if xattr -p com.apple.quarantine ~/Downloads/DSD_Project/geckodriver 2>/dev/null; then
    xattr -d com.apple.quarantine ~/Downloads/DSD_Project/geckodriver
    echo "Quarantine attribute removed from geckodriver."
else
    echo "No quarantine attribute set on geckodriver, ready to use."
fi

python3 client.py
