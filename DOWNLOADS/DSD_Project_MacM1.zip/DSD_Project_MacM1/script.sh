if ! command -v brew &>/dev/null
then
    echo "Homebrew not installed, installing now..."
    /bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/master/install.sh)"
else
    echo "Homebrew is already installed."
fi

# Install Python packages
pip3 install requests PyQt5 selenium cryptography pyNaCl

# Check and remove the quarantine attribute from geckodriver if it exists
if xattr -p com.apple.quarantine ~/Downloads/DSD_Project/geckodriver 2>/dev/null; then
    xattr -d com.apple.quarantine ~/Downloads/DSD_Project/geckodriver
else
    echo "No quarantine attribute set, ready to use."
fi

# Run the Python script
python3 client.py
